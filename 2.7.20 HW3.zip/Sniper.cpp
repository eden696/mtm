#include "Sniper.h"

#define MAX_MOVE 4
#define AMMO_LOAD 2
#define ATTACK_COST 1
#define CRITICAL_HIT_WHEN 2
#define CRITICAL_HIT_BONUS 2


namespace mtm
{

    Sniper::Sniper(Team team, int health_t, int ammo_t, int range_t, int power_t) :
            Character(team, type ,health_t,ammo_t, range_t, power_t,MAX_MOVE),
            ammo_load(AMMO_LOAD),attack_cost(ATTACK_COST),attack_passive(0){}


    Sniper::Sniper(const Sniper& sniper)
    {
        Sniper(sniper.getTeam(),sniper.getHealth(), sniper.getAmmo(),
                sniper.getRange(), sniper.getPower());
    }

    Character* Sniper::clone() const
    {
        return new Sniper(*this);
    }

    bool Sniper::checkLegalAttack(GridPoint location, GridPoint target)
    {
        double distance = GridPoint::distance(location, target);
        double half_range = (this->getRange())/2;
        if((distance > (*this).getRange()) || (distance < (half_range))){
            return false;
        }
        return true;
    }

    //ASSUMING THAT THERE IS A TARGET IN end
    int Sniper::Attack(GridPoint start, GridPoint end)
    {
        this->setAmmo(-1);
        if (this->attack_passive == CRITICAL_HIT_WHEN){
            this->attack_passive = 0;
            return CRITICAL_HIT_BONUS*(*this).getPower();
        }
        this->attack_passive +=1;
        return (*this).getPower();
    }


    const int Sniper::getMaxMove() const
    {
        return (*this).max_move;
    }

    const int Sniper::getAmmoLoad() const
    {
        return (*this).ammo_load;
    }

    const int Sniper::getAttackCost() const
    {
        return (*this).attack_cost;
    }









    void Sniper::setHealth(int health_t)
    {
        (*this).setCharacterHealth(health_t);
    }

    void Sniper::setAmmo(int ammo_t)
    {
        (*this).setCharacterAmmo(ammo_t);
    }
}