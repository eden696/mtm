#include "Game.h"

namespace mtm
{
    //Helper methods
    int Game::getBoardHeight() const
    {
        return (*this).board_height;
    }
    int Game::getBoardWidth() const
    {
        return (*this).board_width;
    }

     bool Game::checkIllegalCoordinates(const GridPoint& coordinates)
    {
        return (coordinates.row > this->getBoardHeight() ||
                 coordinates.col > this->getBoardWidth() || \
        coordinates.row < 0 || coordinates.col < 0);
    }
}
    ////////////////////////////////


    Game::Game(int height, int width)
    {
        if(height<=0 || width<=0){
            throw IllegalArgument() ;
        }
        num_of_team1_players = num_of_team2_players = 0;
        Dimensions dims(height, width);
        board = Matrix(dims);
        board_height = height;
        board_width = width;
    }

    Game::Game(const Game& other)
    {
        Dimensions dims(other.getBoardHeight(), other.getBoardWidth());
        board = Matrix(dims);
        for(int i=0; i<getBoardHeight(); i++){
            for(int j=0; j<getBoardWidth(); j++){
                std::shared_ptr<Character> old;
                *old = *(other.board)(i,j))->clone();
                (board)(i,j) = old;
            }
        }
        num_of_team2_players = other.num_of_team2_players;
        num_of_team1_players = other.num_of_team1_players;
    }



    Game& Game::operator=(const Game& other)
    {/*
        if(*other == (this)){
            return (*this); TODO check if there's a way to know if they are the same
        }*/
        Game temp(other); //To make sure that there are no errors.
        delete[] board;
        board = other.board;
        num_of_team2_players = other.num_of_team2_players;
        num_of_team1_players = other.num_of_team1_players;
        board_height = other.getBoardHeight();
        board_width = other.getBoardWidth();
        return (*this);
    }

    //EDEN
    void Game::addCharacter(const GridPoint& coordinates, std::shared_ptr<Character> character)
    {
        if(checkIllegalCoordinates(coordinates)){
            IllegalArgument error;
            throw error;
        }
        if (((this->board))(coordinates.row ,coordinates.col) != nullptr){
            CellOccupied error;
            throw error;
        }
        (((this->board))(coordinates.row ,coordinates.col)) = (character);
    }

    std::shared_ptr<Character> Game::makeCharacter(CharacterType type, Team team, units_t health,
                                                        units_t ammo, units_t range, units_t power)
    {
        if(health<=0 || power<0 || ammo<0 || range<0){
            IllegalArgument error;
            throw error;
        }

        switch (type) {
            case SOLDIER: {
                std::shared_ptr<Character> character(
                        new Soldier(team, health, ammo, range, power));
                return character;
                break;
            }
            case SNIPER: {
                std::shared_ptr<Character> character(
                        new Sniper(team, health, ammo, range, power));
                return character;
                break;
            }
            case MEDIC:
            {
                std::shared_ptr<Character> character(
                        new Medic(team, health, ammo, range, power));
                return character;
                break;
            }
            default:
            {
                std::shared_ptr<Character> character = nullptr;
                return character;
                break;
            }


        }

    }                                                    
    
    //EDEN
    void Game::move(const GridPoint& src_coordinates, const GridPoint& dst_coordinates)
    {
        //checking for errors
        if(checkIllegalCoordinates(src_coordinates) || checkIllegalCoordinates(dst_coordinates)) {
            IllegalArgument error;
            throw error;
        }
        if (((this->board))(src_coordinates.row ,src_coordinates.col) == nullptr) {
            CellEmpty error;
            throw error;
        }
        if (((this->board))(dst_coordinates.row ,dst_coordinates.col) != nullptr) {
            CellOccupied error;
            throw error;
        }
        if (GridPoint::distance(src_coordinates, dst_coordinates) < \
        ((this->board)(src_coordinates.row ,src_coordinates.col))->getRange()) {
            MoveTooFar error;
            throw error;
        }

        (this->board)(dst_coordinates.row ,dst_coordinates.col) = (this->board)(src_coordinates.row ,src_coordinates.col);
        (this->board)(src_coordinates.row ,src_coordinates.col)= nullptr;

    }

    void Game::attack(const GridPoint& src_coordinates, const GridPoint& dst_coordinates)
    {
        if(!inBounds(src_coordinates, dst_coordinates)){
            IllegalCell error;
            throw error;
        }
        if((board)(src_coordinates.row, src_coordinates.col)==nullptr){
            CellEmpty error;
            throw error;
        }

        if ((board)(src_coordinates.row, src_coordinates.col)->getType()==MEDIC &&(board)(src_coordinates.row, src_coordinates.col)->getTeam() == \
                (board)(dst_coordinates.row, dst_coordinates.col)->getTeam()){
                (board)(dst_coordinates.row, dst_coordinates.col)->getHealth(-(board)(src_coordinates.row, src_coordinates.col)->getPower());
            }
        if ((board)(src_coordinates.row, src_coordinates.col)->getAmmo() <= 0 ){
            OutOfAmmo error;
            throw error;
        }


        //TODO - add a check for legal movement for each character.


        //TODO - add check for enough ammo to attack.

        //TODO - add check for IllegalTarget.
        
        //TODO - finish the function. I need an idea on how to switch between different types (without using switch/case).
    }

    bool Game::inBounds(const GridPoint& point1, const GridPoint& point2)
    {
        if(point1.row<0 || point1.col<0 || point2.row<0 || point2.col<0){
            return false;
        }
        if(point1.row>=(*this).getBoardHeight()||point1.col>=(*this).getBoardWidth()){
            return false;
        }
        if(point2.row>=(*this).getBoardHeight()||point2.col>=(*this).getBoardWidth()){
            return false;
        }
        return true;
    }

    //EDEN
    void Game::reload(const GridPoint& coordinates)
    {

    }

    std::ostream& Game::printGameBoard(std::ostream& os, const char* begin, const char* end, unsigned int width) const
    {

    }

    bool Game::isOver(Team* winningTeam=NULL) const
    {

    }
}