#include "Medic.h"

#define MAX_MOVE 5
#define AMMO_LOAD 5
#define ATTACK_COST 1
#define CRITICAL_HIT_WHEN 2
#define CRITICAL_HIT_BONUS 2


namespace mtm
{

    Medic::Medic(Team team, int health_t, int ammo_t, int range_t, int power_t) :
            Character(team, type ,health_t,ammo_t, range_t, power_t,MAX_MOVE),ammo_load(AMMO_LOAD),attack_cost(ATTACK_COST){}

    Medic::Medic(const Medic& medic)
    {
        Medic(medic.getTeam(),medic.getHealth(), medic.getAmmo(),
               medic.getRange(), medic.getPower());
    }

    Character* Medic::clone() const
    {
        return new Medic(*this);
    }

    //assuming that GridPoint target is not nullptr
    bool Medic::checkLegalAttack(GridPoint location, GridPoint target)
    {
        int distance = GridPoint::distance(location, target);
        //if distance = 0 than its the same cube as the medic itself
        return !(distance > (*this).getRange() || distance == 0);
    }


    int Medic::Attack(GridPoint start, GridPoint end, bool heal_flag)
    {

    }




    const int Medic::getMaxMove() const
    {
        return (*this).max_move;
    }

    const int Medic::getAmmoLoad() const
    {
        return (*this).ammo_load;
    }

    const int Medic::getAttackCost() const
    {
        return (*this).attack_cost;
    }









    void Medic::setHealth(int health_t)
    {
        (*this).setCharacterHealth(health_t);
    }

    void Medic::setAmmo(int ammo_t)
    {
        (*this).setCharacterAmmo(ammo_t);
    }
}