#ifndef SOLDIER_H
#define SOLDIER_H

#include "Character.h"

namespace mtm
{
    class Soldier : public Character
    {
        int max_move, ammo_load, attack_cost;
        CharacterType type = SOLDIER;
    public: 
        explicit Soldier(Team team, int health_t, int ammo_t, int range_t, int power_t);
        Soldier(const Soldier& soldier);
        ~Soldier() = default;

        virtual Character* clone() const;
        bool legalMove(GridPoint start, GridPoint end);//only checks if the start & end points are on the same line. (same row/same column)
        int Attack(GridPoint start, GridPoint end); //NOT checking if the move is legal.
        int adjacentDamage(int distance);
        virtual bool checkLegalAttack(const GridPoint location, const GridPoint target) override ;



        //methods for getting information about the character.
        const int getMaxMove() const;
        const int getAmmoLoad() const;
        const int getAttackCost() const;

        //methods for setting soldier's stats after attack/ loading actions.
        void setHealth(int health_t);
        void setAmmo(int ammo_t);


    };
}

#endif //SOLDIER_H