
#ifndef HW3_MATRIX_H
#define HW3_MATRIX_H

#include "Auxiliaries.h"
#include "Exceptions.h"
#include "Character.h"
#include <memory>

using namespace mtm;

//TODO - check the += we'll see when we'll run tests (looks fine to me)

namespace mtm
{
    class Matrix
    {
    private:
        std::shared_ptr<Character> *matrix;
        unsigned int matHeight, matWidth, matSize;
    public:
        explicit Matrix(const Dimensions dims = {1,1}, std::shared_ptr<Character> value = nullptr);
        Matrix(const Matrix&);
        ~Matrix();

        const unsigned int& height() const;
        const unsigned int& width() const;
        const unsigned int& size() const;

        Matrix& operator=(const Matrix matrix);

        const std::shared_ptr<Character>& operator()(const unsigned int x, const unsigned int y) const;
        std::shared_ptr<Character>& operator()(const unsigned int x, const unsigned int y);

        friend std::ostream &operator<<(std::ostream &os, const Matrix &x);

        class const_iterator;
        const_iterator begin() const;
        const_iterator end() const;

        class iterator;
        iterator begin();
        iterator end();
    };

    std::ostream &operator<<(std::ostream &os, const Matrix &x);

    //Exceptions
    class AccessIllegalElement : public Exception
    {
    public:
        AccessIllegalElement(std::string message_t = "");
        const char* what() const noexcept
        {
            return "Mtm matrix error: An attempt to access an illegal element";
        }
    };

    class IllegalInitialization : public Exception
    {
    public:
        IllegalInitialization(std::string message_t = "");
        const char* what() const noexcept
        {
            return "Mtm matrix error: Illegal initialization values";
        }
    };

    class DimensionMismatch : public Exception
    {
        std::string message;
        const std::string description;
    public:
        DimensionMismatch(unsigned int matrix1_h, unsigned int matrix1_w,
                          unsigned int matrix2_h, unsigned int matrix2_w,
                          std::string description = "Mtm matrix error: Dimension mismatch: ")
        {
            Dimensions dims1(matrix1_h, matrix1_w);
            Dimensions dims2(matrix2_h, matrix2_w);
            message = description + dims1.toString() + " " + dims2.toString();
        }

        virtual ~DimensionMismatch() = default;

        const char* what() const noexcept
        {
            return (message.c_str());
        }
    };

    //Iterators
    class Matrix::iterator
    {
    private:
        Matrix *matrix;
        unsigned int index;
        iterator(Matrix *a_matrix, unsigned int an_index);
        friend class Matrix;

    public:
        std::shared_ptr<Character>& operator*();
        iterator& operator++();
        iterator operator++(int);
        bool operator==(const iterator &it) const;
        bool operator!=(const iterator &it) const;

        iterator(const iterator &) = default;
        iterator &operator=(const iterator &) = default;
    };

    //Methods

    Matrix::Matrix(const Dimensions dims, std::shared_ptr<Character> value)
    {
        if(dims.getCol()<0 || dims.getRow()<0){ //Sends error if the initialization values are illegal.
            IllegalInitialization error;
            throw error;
        }

        matHeight = dims.getRow();
        matWidth = dims.getCol();
        matSize = matHeight * matWidth;

        matrix = new std::shared_ptr<Character>[matSize];

        for (unsigned int i = 0; i < matSize; i++) {
            matrix[i] = value;
        }
    }


    Matrix::Matrix(const Matrix& old_matrix) :
            matrix(new std::shared_ptr<Character>[old_matrix.size()]), matHeight(old_matrix.height()),
            matWidth(old_matrix.width()), matSize(old_matrix.size())
    {
        for (unsigned int i = 0; i < old_matrix.size(); i++) {
            matrix[i] = old_matrix.matrix[i];
        }
    }

    Matrix::~Matrix()
    {
        delete[] matrix;
    }

    Matrix& Matrix::operator=(const Matrix x)
    {
        if (this == &x) {
            return *this;
        }
        delete[] matrix;
        matSize = x.matSize;
        matHeight = x.matHeight;
        matWidth = x.matWidth;
        matrix = new std::shared_ptr<Character>[matSize];

        for (unsigned int i = 0; i < x.matSize; i++) {
            matrix[i] = x.matrix[i];
        }
        return *this;
    }

    std::ostream& operator<<(std::ostream &os, Matrix &matrix)
    {
        return printMatrix(os, matrix.begin(), matrix.end(), matrix.width());
    }

    const std::shared_ptr<Character>& Matrix::operator()(const unsigned int x, const unsigned int y) const
    {
        if ((x < 0) || (y < 0) || (x >= (*this).matHeight) || (y >= (*this).matWidth)) {
            throw AccessIllegalElement();
        }
        return (*this).matrix[x * (*this).matWidth + y];
    }

    std::shared_ptr<Character>& Matrix::operator()(const unsigned int x, const unsigned int y)
    {
        if ((x < 0) || (y < 0) || (x >= (*this).matHeight) || (y >= (*this).matWidth)) {
            throw AccessIllegalElement();
        }
        return (*this).matrix[x * (*this).matWidth + y];
    }

    //Iterator's methods
    Matrix::iterator::iterator(Matrix *a_matrix, unsigned int an_index)
    {
        index = an_index;
        matrix = a_matrix;
    }

    std::shared_ptr<Character>& Matrix::iterator::operator*()
    {
        if ((index < 0) || (index >= ((this->matrix)->matSize))){
            throw AccessIllegalElement();
        }
        return (*matrix).matrix[index];
    }

    typename Matrix::iterator& Matrix::iterator::operator++()
    {
        ++index;
        return *this;
    }

    typename Matrix::iterator Matrix::iterator::operator++(int)
    {
        iterator result = *this;
        ++*this;
        return result;
    }

    bool Matrix::iterator::operator==(const iterator &it) const
    {
        return index == it.index;
    }

    bool Matrix::iterator::operator!=(const iterator &it) const
    {
        return !(*this == it);
    }

    typename Matrix::iterator Matrix::begin()
    {
        return iterator(this, 0);
    }

    typename Matrix::iterator Matrix::end()
    {
        return iterator(this, matSize);
    }

}

#endif //HW3_MATRIX_H