#ifndef CHARACTER_H
#define CHARACTER_H

#include "Auxiliaries.h"
#include <cmath>


namespace mtm
{
    class Character
    {
        int health, ammo, range, power,max_move;
        Team team;
        CharacterType type;
    protected:
        Character();
        explicit Character(Team team_t, CharacterType type_t,\
                        units_t health_t = 0, units_t ammo_t = 0, units_t range_t = 0, units_t power_t = 0,units_t max_move_t =0);
        Character(const Character& character);

    public:
        virtual Character* clone() const = 0;
        virtual ~Character() = default;
        //methods for getting information about the character.
        //when there's no param in  the method (nt n=0) the function will say how much health/ammo the character has.
        int getHealth()const;//TODO - ASK VIKA IF THERES A NEED FOR VIRTUAL HERE?
        int getAmmo()const;
        int getRange() const;
        int getPower() const;
        Team getTeam() const;
        CharacterType getType() const;
        //lets us know if the character can move
        bool canMove(const GridPoint location, const GridPoint target);
        virtual bool checkLegalRange(const GridPoint location, const GridPoint target) = 0;
        virtual int strike() = 0;


        friend class Exception;
        };
}

#endif //CHARACTER_H