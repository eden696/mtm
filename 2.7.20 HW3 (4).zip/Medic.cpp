#include "Medic.h"

#define MAX_MOVE 5
#define AMMO_LOAD 5
#define ATTACK_COST 1



namespace mtm
{

    Medic::Medic(Team team, int health_t, int ammo_t, int range_t, int power_t) :
            Character(team, type ,health_t,ammo_t, range_t, power_t,MAX_MOVE),ammo_load(AMMO_LOAD),attack_cost(ATTACK_COST){}

    Medic::Medic(const Medic& medic)
    {
        Medic(medic.getTeam(),medic.getHealth(), medic.getAmmo(),
               medic.getRange(), medic.getPower());
    }

    Character* Medic::clone() const
    {
        return new Medic(*this);
    }

    //assuming that GridPoint target is not nullptr
    bool Medic::checkLegalRange(GridPoint location, GridPoint target)
    {
        int distance = GridPoint::distance(location, target);
        //if distance = 0 WE GOT BEFORE AN ERROR
        return !(distance > (*this).getRange() );
    }

    int Medic::strike()
    {
        //todo if ammo function was changed 0 implament in all strikes in every character
        this->setAmmo(-1);
        return (*this).getPower();
    }




    const int Medic::getMaxMove() const
    {
        return (*this).max_move;
    }

    const int Medic::getAmmoLoad() const
    {
        return (*this).ammo_load;
    }

    const int Medic::getAttackCost() const
    {
        return (*this).attack_cost;
    }









    void Medic::setHealth(int health_t)
    {
        (*this).setCharacterHealth(health_t);
    }

    void Medic::setAmmo(int ammo_t)
    {
        (*this).setCharacterAmmo(ammo_t);
    }
}