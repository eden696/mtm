#include "Character.h"

namespace mtm
{
    Character::Character(Team team_t,CharacterType type_t,units_t health_t, units_t ammo_t,units_t range_t,units_t power_t, units_t max_move_t):
                        team(team_t), type(type_t) ,health(health_t),
                        ammo(ammo_t), range(range_t), power(power_t),max_move(max_move_t)
    {}

    Character::Character(const Character& character)
    {
        this->team = character.team;
        this->type = character.type;
        this->health = character.health;
        this->ammo = character.ammo;
        this->range = character.range;
        this->power = character.power;
        this->max_move = character.max_move;
    }

     int Character::getHealth()
    {
        return this->health;
    }

     int Character::getAmmo()
    {
        return this->ammo;
    }

    int Character::getRange() const
    {
        return this->range;
    }

    int Character::getPower() const
    {
        return this->power;
    }


    Team Character::getTeam() const
    {
        return (*this).team;
    }

    CharacterType Character::getType() const
    {
        return (*this).type;
    }
    bool Character::canMove(const GridPoint location, const GridPoint target)
    {
        int distance = GridPoint::distance(location, target);
        return distance <= (*this).getRange();
    }

}