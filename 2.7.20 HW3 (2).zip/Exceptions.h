#ifndef EXCEPTION_H
#define EXCEPTION_H
#include <exception>
#include <string>


namespace mtm
{
    class Exception         : public std::exception
    {
        std::string message;
    protected:
        Exception(std::string message_t);
    public:
        const char* what() const noexcept;
    };
    /*_________________________GameException____________________________*/

    class GameException     : public Exception
    {
    protected:
        GameException(std::string message_t, std::string description_t = "A game related error has occured: ");
    };

    struct IllegalArgument  : public GameException
    {
        IllegalArgument();
    };

    struct IllegalCell      : public GameException
    {
        IllegalCell();
    };
    struct CellEmpty        : public GameException
    {
        CellEmpty();
    };
    struct MoveTooFar       : public GameException
    {
        MoveTooFar();
    };
    struct CellOccupied     : public GameException
    {
        CellOccupied();
    };
    struct OutOfRange       : public GameException
    {
        OutOfRange();
    };
    struct OutOfAmmo        : public GameException
    {
        OutOfAmmo();
    };
    struct IllegalTarget    : public GameException
    {
        IllegalTarget();
    };
}

#endif //EXCEPTION_H