#ifndef SNIPER_H
#define SNIPER_H

#include "Character.h"
#include <cmath>

namespace mtm {
    class Sniper : public Character {
        int max_move, ammo_load, attack_cost, attack_passive;
        CharacterType type = SNIPER;
    public:
        explicit Sniper(Team team, int health_t, int ammo_t, int range_t,int power_t);
        Sniper(const Sniper &Sniper);
        ~Sniper() = default;
        virtual Character *clone() const; //TODO ASKE VIKA IF EHIS NEEDED TO BR IN THE DAD CLASS

        //methods for getting information about the character.
        const int getMaxMove() const;

        const int getAmmoLoad() const;

        const int getAttackCost() const;

        //methods for setting sniper's stats after attack/ loading actions.
        void setHealth(int health_t);

        void setAmmo(int ammo_t);

        // checks if the target is in sniper available attack rang

        virtual bool checkLegalRange(const GridPoint location, const GridPoint target) override ;
        int Attack(GridPoint start,GridPoint end); //NOT checking if the move is legal.



    };
}

#endif //SNIPER_H