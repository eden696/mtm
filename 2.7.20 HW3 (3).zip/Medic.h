#ifndef MEDIC_H
#define MEDIC_H

#include "Character.h"

namespace mtm
{
    class Medic : public Character
    {
        int max_move, ammo_load, attack_cost;
        CharacterType type = MEDIC;
    public:
        explicit Medic(Team team, int health_t, int ammo_t, int range_t, int power_t);
        Medic(const Medic& medic);
        ~Medic() = default;

        virtual Character* clone() const;
        bool legalMove(GridPoint start, GridPoint end);
        int Attack(GridPoint start, GridPoint end); //NOT checking if the move is legal.
        int adjacentDamage(int distance);
        virtual bool checkLegalRange(const GridPoint location, const GridPoint target) override ;


        //methods for getting information about the character.
        const int getMaxMove() const;
        const int getAmmoLoad() const;
        const int getAttackCost() const;

        //methods for setting soldier's stats after attack/ loading actions.
        void setHealth(int health_t);
        void setAmmo(int ammo_t);


    };
}

#endif //MEDIC_H