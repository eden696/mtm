#include "Exceptions.h"

namespace mtm
{
    Exception::Exception(std::string message_t) : message(message_t){}

    const char* Exception::what() const noexcept
    {
        return const_cast<char*>(message.c_str());
    }

    GameException::GameException(std::string message_t, std::string description_t)
                                : Exception(description_t + message_t){}
    
    IllegalArgument::IllegalArgument()  : GameException("IllegalArgument") {}
    IllegalCell::IllegalCell()          : GameException("IllegalCell") {}
    CellEmpty::CellEmpty()              : GameException("CellEmpty") {}
    MoveTooFar::MoveTooFar()            : GameException("MoveTooFar") {}
    CellOccupied::CellOccupied()        : GameException("CellOccupied") {}
    OutOfAmmo::OutOfAmmo()              : GameException("OutOfAmmo") {}
    OutOfRange::OutOfRange()            : GameException("OutOfRange") {}
    IllegalTarget::IllegalTarget()      : GameException("IllegalTarget") {}
}
