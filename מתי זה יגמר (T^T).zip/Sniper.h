#ifndef SNIPER_H
#define SNIPER_H

#include "Character.h"
#include <cmath>

namespace mtm {
    class Sniper : public Character {
        int max_move, ammo_load, attack_cost, attack_passive;
        CharacterType type = SNIPER;
    public:
        explicit Sniper(Team team, int health_t, int ammo_t, int range_t,
                        int power_t);

        Sniper(const Sniper &Sniper);

        ~Sniper() = default;

        virtual Character *clone() const;

        bool checkLegalAttack(GridPoint location, GridPoint target);// checks if the target is in sniper available attack rang
        int Attack(GridPoint start,GridPoint end); //NOT checking if the move is legal.

        //methods for getting information about the character.
        const int getMaxMove() const;

        const int getAmmoLoad() const;

        const int getAttackCost() const;

        //methods for setting sniper's stats after attack/ loading actions.
        void setHealth(int health_t);

        void setAmmo(int ammo_t);


    };
}

#endif //SNIPER_H