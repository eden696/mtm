#include "Character.h"

namespace mtm
{
    Character::Character(Team team_t, CharacterType type_t,
                        units_t health_t, units_t ammo_t, units_t range_t, units_t power_t) :
                        team(team_t), type(type_t) ,health(health_t),
                        ammo(ammo_t), range(range_t), power(power_t)
    {}

    Character::Character(const Character& character)
    {
        this->team = character.team;
        this->type = character.type;
        this->health = character.health;
        this->ammo = character.ammo;
        this->range = character.range;
        this->power = character.power;
    }

     int Character::getHealth(int n=0) const
    {
        this->health = (this->health)+n
        return this->health;
    }

     int Character::getAmmo() const
    {
        return this->ammo;
    }

    int Character::getRange() const
    {
        return this->range;
    }

    int Character::getPower() const
    {
        return this->power;
    }

    void Character::setCharacterHealth(int health_t)
    {
        this->health = health_t;
    }

    void Character::setCharacterAmmo(int ammo_t)
    {
        this->ammo = ammo_t;
    }

    void Character::setCharacterRange(int range_t)
    {
        this->range = range_t;
    }

    void Character::setCharacterPower(int power_t)
    {
        this->power = power_t;
    }

    Team Character::getTeam() const
    {
        return (*this).team;
    }

    CharacterType Character::getType() const
    {
        return (*this).type;
    }

    int Character::distance(const GridPoint &point1, const GridPoint &point2) {
        return 	std::abs(point1.row - point2.row)
                  + std::abs(point1.col - point2.col);
    }

}