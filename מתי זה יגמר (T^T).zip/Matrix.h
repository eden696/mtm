
#ifndef HW3_MATRIX_H
#define HW3_MATRIX_H

#include "Auxiliaries.h"
#include "Exceptions.h"

using namespace mtm;

//TODO - check the += well see when well run tests (looks fine to me)

namespace mtm
{
    template<class T>
    class Matrix
    {
    private:
        //Assuming T has c'tor, d'tor and copy c'tor.
        T *matrix;
        unsigned int matHeight, matWidth, matSize;
    public:
        explicit Matrix(const Dimensions dims = {1,1}, T value = T());
        Matrix(const Matrix&);
        ~Matrix();

        const unsigned int& height() const;
        const unsigned int& width() const;
        const unsigned int& size() const;

        Matrix& operator=(const Matrix matrix);
        static Matrix Diagonal(const int size, const T value);
        Matrix transpose() const;
        Matrix operator-() const;
        Matrix operator-(const Matrix matrix) const;
        Matrix operator+=(const T num) const;
        Matrix<bool> operator<(const T value);
        Matrix<bool> operator>(const T value);
        Matrix<bool> operator<=(const T value);
        Matrix<bool> operator>=(const T value);
        Matrix<bool> operator==(const T value);
        Matrix<bool> operator!=(const T value);
        const T& operator()(const unsigned int x, const unsigned int y) const;
        T& operator()(const unsigned int x, const unsigned int y);
        template <typename Obj>
        Matrix apply(Obj obj) const;

        template<class U>
        friend bool all (const Matrix<U> matrix);
        template<class U>
        friend bool any (const Matrix<U> matrix);
        template<class U>
        friend Matrix operator+(const Matrix matrix1, const Matrix matrix2);
        template<class U>
        friend Matrix operator-(const Matrix matrix1, const Matrix matrix2);
        template<class U>
        friend Matrix operator+(const Matrix &matrix1, const T value);
        template<class U>
        friend Matrix operator+(const T value, const Matrix& matrix1);
        template<class U>
        friend std::ostream &operator<<(std::ostream &os, const Matrix &x);

        class const_iterator;
        const_iterator begin() const;
        const_iterator end() const;

        class iterator;
        iterator begin();
        iterator end();

    };

    //friend declaration
    template<class T>
    Matrix<T> operator+(const Matrix<T>& matrix1, const Matrix<T>& matrix2);

    template<class T>
    Matrix<T> operator-(const Matrix<T> matrix1, const Matrix<T> matrix2);

    template<class T>
    Matrix<T> operator+(const Matrix<T>& my_matrix, const T value);

    template<class T>
    Matrix<T> operator+(const T value, const Matrix<T>& my_matrix);

    template<class T>
    std::ostream &operator<<(std::ostream &os, const Matrix<T> &x);

    //Iterators
    template<class T>
    class Matrix<T>::iterator
    {
    private:
        Matrix<T> *matrix;
        unsigned int index;
        iterator(Matrix<T> *a_matrix, unsigned int an_index);
        friend class Matrix<T>;

    public:
        T& operator*();
        iterator& operator++();
        iterator operator++(int);
        bool operator==(const iterator &it) const;
        bool operator!=(const iterator &it) const;

        iterator(const iterator &) = default;
        iterator &operator=(const iterator &) = default;
    };

    template<class T>
    class Matrix<T>::const_iterator
    {
    private:
        const Matrix<T> *matrix;
        unsigned int index;
        const_iterator(const Matrix<T> *a_matrix, unsigned int an_index);
        friend class Matrix;

    public:
        const T& operator*() const;
        const_iterator& operator++();
        const_iterator operator++(int);
        bool operator==(const const_iterator &it) const;
        bool operator!=(const const_iterator &it) const;

        const_iterator(const const_iterator &) = default;
        const_iterator &operator=(const const_iterator &) = default;
    };


    //Methods
    template<class T>
    Matrix<T>::Matrix(const Dimensions dims, T value)
    {
        if(dims.getCol()<0 || dims.getRow()<0){ //Sends error if the initialization values are illegal.
            IllegalInitialization error;
            throw error;
        }

        matHeight = dims.getRow();
        matWidth = dims.getCol();
        matSize = matHeight * matWidth;

        matrix = new T[matSize];

        for (unsigned int i = 0; i < matSize; i++) {
            matrix[i] = value;
        }
    }



    template<class T>
    Matrix<T>::Matrix(const Matrix& old_matrix) :
            matrix(new T[old_matrix.size()]), matHeight(old_matrix.height()),
            matWidth(old_matrix.width()), matSize(old_matrix.size())
    {
        for (unsigned int i = 0; i < old_matrix.size(); i++) {
            matrix[i] = old_matrix.matrix[i];
        }
    }

    template<class T>
    Matrix<T>::~Matrix()
    {
        /*for(int i=0; i<size(); i++){
            delete matrix[i];
        }*/
        delete[] matrix;
    }

    template<class T>
    Matrix<T>& Matrix<T>::operator=(const Matrix x)
    {
        if (this == &x) {
            return *this;
        }
        delete[] matrix;
        matSize = x.matSize;
        matHeight = x.matHeight;
        matWidth = x.matWidth;
        matrix = new T[matSize];

        for (unsigned int i = 0; i < x.matSize; i++) {
            matrix[i] = x.matrix[i];
        }
        return *this;
    }

    template<class T>
    Matrix<T> Matrix<T>::Diagonal(const int size, const T value)
    {
        Dimensions dims(size,size);
        Matrix<T> matrix(dims); //Will throw error if the size is illegal or if there was a bad_alloc.

        for(int i=0; i<size; i++){
            matrix(i,i)=value;
        }

        return matrix;
    }

    template<class T>
    const unsigned int& Matrix<T>::height() const
    {
        return matHeight;
    }

    template<class T>
    const unsigned int& Matrix<T>::width() const
    {
        return matWidth;
    }

    template<class T>
    const unsigned int& Matrix<T>::size() const
    {
        return matSize;
    }

    template<class T>
    Matrix<T> Matrix<T>::transpose() const
    {
        Dimensions dims((*this).matWidth, (*this).matHeight);
        Matrix<T> my_matrix(dims); //Will throw errors if there are any.

        my_matrix.matSize = (*this).matSize;
        my_matrix.matHeight = (*this).matWidth;
        my_matrix.matWidth = (*this).matHeight;

        for(unsigned int i=0; i<matWidth; i++){
            for(unsigned int j=0; j<matHeight; j++){
                my_matrix.matrix[i*matHeight+j] =  matrix[j*matWidth+i];
            }
        }
        return my_matrix;
    }

    template<class T>
    Matrix<T> operator+(const Matrix<T>& matrix1, const Matrix<T>& matrix2)
    {
        if(matrix1.height()!=matrix2.height() || matrix1.width()!=matrix2.width()){
            throw typename Matrix<T>::DimensionMismatch(matrix1.height(), matrix1.width(), matrix2.height(), matrix2.width());
        }

        Matrix<T> sum_matrix = matrix1;
        for(unsigned int i=0; i<matrix1.height(); i++)
        {
            for(unsigned int j=0; j<matrix1.width(); j++){
                sum_matrix(i,j) += matrix2(i,j);
            }
        }

        return sum_matrix;
    }


    template<class T>
    Matrix<T> Matrix<T>::operator-() const
    {
        Matrix<T> new_matrix = *this;
        for (unsigned int i = 0; i < (*this).matSize; i++)
        {
            new_matrix.matrix[i] = -new_matrix.matrix[i];
        }
        return new_matrix;
    }

    template<class T>
    Matrix<T> Matrix<T>::operator-(const Matrix<T> matrix) const
    {
        Matrix<T> temp_matrix = *this;
        return temp_matrix + (-matrix);
    }

    template<class T>
    Matrix<T> operator-(const Matrix<T> matrix1, const Matrix<T> matrix2)
    {
        return matrix1 + (-matrix2);
    }

    template<class T>
    Matrix<T> Matrix<T>::operator+=(const T value) const
    {
        Matrix new_matrix = *this;
        for (unsigned int i = 0; i < new_matrix.size(); i++)
        {
            new_matrix.matrix[i] += value;
        }
        return new_matrix;
    }

    template<class T>
    Matrix<T> operator+(const Matrix<T>& my_matrix, const T value)
    {
        Matrix<T> sum_matrix(my_matrix);
        return (sum_matrix += value);
    }

    template<class T>
    Matrix<T> operator+(const T value, const Matrix<T>& my_matrix)
    {
        return my_matrix + value;
    }

    template<class T>
    std::ostream& operator<<(std::ostream &os, const Matrix<T> &matrix)
    {
        return printMatrix(os, matrix.begin(), matrix.end(), matrix.width());
    }

    template<class T>
    Matrix<bool> Matrix<T>::operator<(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] < value;
            }
        }
        return new_matrix;
    }

    template<class T>
    Matrix<bool> Matrix<T>::operator>(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] > value;
            }
        }
        return new_matrix;
    }

    template<class T>
    Matrix<bool> Matrix<T>::operator<=(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] <= value;
            }
        }
        return new_matrix;
    }

    template<class T>
    Matrix<bool> Matrix<T>::operator>=(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] >= value;
            }
        }
        return new_matrix;
    }

    template<class T>
    Matrix<bool> Matrix<T>::operator==(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] == value;
            }
        }
        return new_matrix;



    }

    template<class T>
    Matrix<bool> Matrix<T>::operator!=(const T value)
    {
        Dimensions dims(matHeight,matWidth);
        Matrix<bool> new_matrix(dims, false);

        for(unsigned int i=0; i<this->matHeight; i++)
        {
            for(unsigned int j=0; j<this->matWidth; j++){
                new_matrix(i,j) = this->matrix[i*matWidth +j] != value;
            }
        }
        return new_matrix;
    }

    template<class T>
    const T& Matrix<T>::operator()(const unsigned int x, const unsigned int y) const
    {
        //std::cout<<"line 451 in Matrix.h"<<(*this).matHeight<<std::endl;
        if ((x < 0) || (y < 0) || (x >= (*this).matHeight) || (y >= (*this).matWidth)) {
            std::cout<<"line 453 in Matrix.h"<<std::endl;
            throw AccessIllegalElement();
        }
        return (*this).matrix[x * (*this).matWidth + y];
    }

    template<class T>
    T& Matrix<T>::operator()(const unsigned int x, const unsigned int y)
    {
        if ((x < 0) || (y < 0) || (x >= (*this).matHeight) || (y >= (*this).matWidth)) {
            throw AccessIllegalElement();
        }
        return (*this).matrix[x * (*this).matWidth + y];
    }

    template <class T>
    template <typename Obj>
    Matrix<T> Matrix<T>::apply (Obj obj) const
    {
        Matrix<T> new_matrix = *this;
        for (unsigned int i = 0; i < matHeight ; ++i){
            for(unsigned int j=0; j < matWidth; j++){
                new_matrix(i,j) = obj(new_matrix(i,j));
            }
        }
        return new_matrix;
    }


    //Iterator's methods
    template<class T>
    Matrix<T>::iterator::iterator(Matrix<T> *a_matrix, unsigned int an_index)
    {
        index = an_index;
        matrix = a_matrix;
    }

    template<class T>
    T& Matrix<T>::iterator::operator*()
    {
        if ((index < 0) || (index >= ((this->matrix)->matSize))){
            throw AccessIllegalElement();
        }
        return (*matrix).matrix[index];
    }

    template<class T>
    typename Matrix<T>::iterator& Matrix<T>::iterator::operator++()
    {
        ++index;
        return *this;
    }

    template<class T>
    typename Matrix<T>::iterator Matrix<T>::iterator::operator++(int)
    {
        iterator result = *this;
        ++*this;
        return result;
    }

    template<class T>
    bool Matrix<T>::iterator::operator==(const iterator &it) const
    {
        return index == it.index;
    }

    template<class T>
    bool Matrix<T>::iterator::operator!=(const iterator &it) const
    {
        return !(*this == it);
    }

    template<class T>
    typename Matrix<T>::iterator Matrix<T>::begin()
    {
        return iterator(this, 0);
    }

    template<class T>
    typename Matrix<T>::iterator Matrix<T>::end()
    {
        return iterator(this, matSize);
    }


    //const_iterator's methods
    template<class T>
    Matrix<T>::const_iterator::const_iterator(const Matrix<T> *a_matrix, unsigned int an_index)
    {
        index = an_index;
        matrix = a_matrix;
    }

    template<class T>
    const T& Matrix<T>::const_iterator::operator*() const
    {
        if ((index < 0) || (index >= ((this->matrix)->matSize))){
            throw AccessIllegalElement();
        }
        return (*matrix).matrix[index];
    }

    template<class T>
    typename Matrix<T>::const_iterator& Matrix<T>::const_iterator::operator++()
    {
        ++index;
        return *this;
    }

    template<class T>
    typename Matrix<T>::const_iterator Matrix<T>::const_iterator::operator++(int)
    {
        const_iterator result = *this;
        ++*this;
        return result;
    }

    template<class T>
    bool Matrix<T>::const_iterator::operator==(const const_iterator &it) const
    {
        return index == it.index;
    }

    template<class T>
    bool Matrix<T>::const_iterator::operator!=(const const_iterator &it) const
    {
        return !(*this == it);
    }

    template<class T>
    typename Matrix<T>::const_iterator Matrix<T>::begin() const
    {
        return const_iterator(this, 0);
    }

    template<class T>
    typename Matrix<T>::const_iterator Matrix<T>::end() const
    {
        return const_iterator(this, matSize);
    }

    template<class T>
    bool all (const mtm::Matrix<T> matrix)
    {
        for (unsigned int i=0; i<matrix.matSize; i++){
            if (!(bool) matrix.matrix[i]){
                return false;
            }
        }
        return true;
    }

    template<class T>
    bool any(mtm::Matrix<T> matrix)
    {
        for (unsigned int i=0; i<matrix.matSize; i++){
            if ((bool) matrix.matrix[i]){
                return true;
            }
        }
        return false;
    }

}

#endif //HW3_MATRIX_H


