#include "Soldier.h"
#include <cmath>

#define MAX_MOVE 3
#define AMMO_LOAD 3
#define ATTACK_COST 1

namespace mtm
{
    Soldier::Soldier(Team team, int health_t, int ammo_t, int range_t, int power_t) :
                    Character(team, type ,health_t,ammo_t, range_t, power_t)
    {
        this->max_move = MAX_MOVE;
        this->ammo_load = AMMO_LOAD;
        this->attack_cost = ATTACK_COST;
    }

    Soldier::Soldier(const Soldier& soldier)
    {
        Soldier(soldier.getTeam(),soldier.getHealth(), soldier.getAmmo(),
                soldier.getRange(), soldier.getPower());
    }

    Character* Soldier::clone() const
    {
        return new Soldier(*this);
    }

    bool Soldier::checkLegalAttack(GridPoint start, GridPoint end)
    {
        if((start.row!=end.row) && (start.col!=end.col)){
            return false;
        }
        return !(GridPoint::distance(start, end) > (*this).getRange());
    }

    int Soldier::Attack(GridPoint start, GridPoint end)
    {
        return (*this).getPower(); //todo - check if were attacking outside of the grid
    }

    int Soldier::adjacentDamage(int distance)
    {
        if(distance<(int)(ceil((*this).getRange()/3)+0.5)){
            return (int)(ceil((*this).getPower()/2)+0.5);
        }
        return 0;
    }

    const int Soldier::getMaxMove() const
    {
        return (*this).max_move;
    }

    const int Soldier::getAmmoLoad() const
    {
        return (*this).ammo_load;
    }

    const int Soldier::getAttackCost() const
    {
        return (*this).attack_cost;
    }

    void Soldier::setHealth(int health_t)
    {
        (*this).setCharacterHealth(health_t);
    }

    void Soldier::setAmmo(int ammo_t)
    {
        (*this).setCharacterAmmo(ammo_t);
    }
}