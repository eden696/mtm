#ifndef CHARACTER_H
#define CHARACTER_H

#include "Auxiliaries.h"
#include <cmath>

namespace mtm
{
    class Character
    {
        int health, ammo, range, power;
        Team team;
        CharacterType type;
    protected:
        Character();
        explicit Character(Team team_t, CharacterType type_t,\
                        units_t health_t = 0, units_t ammo_t = 0, units_t range_t = 0, units_t power_t = 0);
        Character(const Character& character);



        //methods for setting character parameters.
        void setCharacterHealth(int health_t);
        void setCharacterAmmo(int ammo_t);
        void setCharacterRange(int range_t);
        void setCharacterPower(int power_t);    
    public:
        virtual Character* clone() const = 0;
        virtual ~Character() = default;
        friend class Exception;
        int distance(const GridPoint& point1, const GridPoint& point2);
        //methods for getting information about the character.
        virtual int getHealth(int n=0) ;
        virtual int getAmmo(int n=0) ;
        int getRange() ;
        int getPower() ;
        Team getTeam() const;
        CharacterType getType() const;
        };
}

#endif //CHARACTER_H