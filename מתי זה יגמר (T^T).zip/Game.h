#ifndef GAME_H
#define GAME_H

#include "Matrix.h"
#include "Soldier.h"
#include "Medic.h"
#include "Sniper.h"
#include "Auxiliaries.h"
#include "Character.h"
#include <memory>

namespace mtm
{
    class Game
    {
        int board_height, board_width;
        Matrix <std::shared_ptr<Character>> board; //A matrix of pointers to characters..
        int num_of_team1_players, num_of_team2_players; //will keep a record of the number of players in each team.

        //Extra methods.
        int getBoardHeight() const;
        int getBoardWidth() const;
        bool inBounds(const GridPoint& point1, const GridPoint& point2);
        bool checkIllegalCoordinates(const GridPoint& coordinates);
    public:
        Game(int height, int width);
        Game(const Game& other);
        ~Game();

        Game& operator=(const Game& other);
        void addCharacter(const GridPoint& coordinates, std::shared_ptr<Character> character);
        static std::shared_ptr<Character> makeCharacter(CharacterType type, Team team, units_t health,
                                                        units_t ammo, units_t range, units_t power);
        void move(const GridPoint& src_coordinates, const GridPoint& dst_coordinates);
        void attack(const GridPoint& src_coordinates, const GridPoint& dst_coordinates);
        void reload(const GridPoint& coordinates);
        std::ostream& printGameBoard(std::ostream& os, const char* begin, const char* end, unsigned int width) const;
        bool isOver(Team* winningTeam=NULL) const;


    };
}

#endif //GAME_H